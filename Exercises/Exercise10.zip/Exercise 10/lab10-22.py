# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 08:33:10 2017

@author: Abdul Rehman
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 07:19:08 2017

@author: Abdul Rehman
"""


import sklearn.svm.libsvm as svm
from sklearn.svm import SVC 
import numpy as np
from sklearn.metrics import accuracy_score as score
import pandas as pd
import time
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
import operator


print(final)