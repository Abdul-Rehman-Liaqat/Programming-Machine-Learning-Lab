# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 07:19:08 2017

@author: Abdul Rehman
"""


import sklearn.svm.libsvm as svm
from sklearn.svm import SVC 
import numpy as np
from sklearn.metrics import accuracy_score as score
import pandas as pd
import time
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.grid_search import GridSearchCV as cv
# separating target and input variables.
def sepxy(df,col):
    x=df.drop(col,axis=1)
    y=df[col]
    return x,y
'''
# normalizing the whole numerical data
def normalize(df,col):
    for x in col:
        mean=df[x].mean()
        std=df[x].std()
        df[x]=(df[x]-mean)/std
    return df
'''
def normalize(df,col):
    for x in col:
        ma=max(df[x])
        mi=min(df[x])
        if(ma-mi==0):
            df[x]=0
        else:
            df[x]=(df[x]-mi)/(ma-mi)
    return df

# Randomly shuffling the whole dataframe with respect to rows.
def shuffleit(df):
    df=df.sample(frac=1)
    return df.reset_index(drop='true')

# Separating and returning dataframe parts according to K-fold configuration.
def separate(df,k,num):
    if (k*num<=len(df) and k*2<len(df)):
        valid=df.iloc[k*(num-1):k*num]
        train=df.drop(range(k*(num-1),k*num),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    elif (k*num<=len(df) and k*2>len(df)):        
        valid=df.iloc[k*num:]
        train=df.drop(range(k*num,len(df)),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    else:
        valid=df.iloc[k*(num-1):]
        train=df.drop(range(k*(num-1),len(df)),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    
data=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\10th\\smsspamcollection\\SMSSpam.csv',header=None)
data=data.drop(data.index[0])
data=data.reset_index(drop='true')
print(data.head())
coll=len(data.iloc[0])
col=np.arange(0,coll,dtype=int)
tempcol=np.arange(0,coll-1,dtype=int)
data.columns=col
pred=col[-1]
data=shuffleit(data)
df,test=separate(data,int(0.2*len(data)),1)

df=normalize(df,tempcol)

test=normalize(test,tempcol)
trainx,trainy=sepxy(df,pred)
testx,testy=sepxy(test,pred)

const=[0.001,0.01,0.1,1,10,100,1000,10000]
init=[0.001,0.01,0.1,1,10]
parameters={'alpha':const,'eta0':init}
clas=linear_model.SGDClassifier(loss='log')
clf=cv(clas,parameters)
clf.fit(trainx,trainy)
predict=clf.predict(testx)
print(score(predict,testy))
