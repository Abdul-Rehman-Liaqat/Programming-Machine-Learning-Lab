# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 07:19:08 2017

@author: Abdul Rehman
"""


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import operator
from itertools import islice
import numpy as np


def take(n, iterable):
    return list(islice(iterable, n))

df=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\10th\\smsspamcollection\\SMSSpamCollection',header=None, sep='\t')
col=[0,1]
#df=data.iloc[0:5]
df.columns=col
#count=[]
line=[]

print(len(df))

for x in range(len(df)):
    if(df.iloc[x][0]=='spam'):
        line.append(df.iloc[x][1])
        
vectorizer = TfidfVectorizer(min_df=1)
X = vectorizer.fit_transform(line)
idf = vectorizer.idf_
x=(dict(zip(vectorizer.get_feature_names(), idf)))
sorted_x = dict(sorted(x.items(), key=operator.itemgetter(1)))
#print(type(sorted_x))
vocab=list(sorted_x.keys())
final=[]
count=0
for x in vocab:
    if (not x.isdigit()):
        final.append(x)
        count=count+1
    if(count==99):
        break
    
final=list(final)
#print(final)
temp=[]
#data.columns=col
vectorizer = TfidfVectorizer(min_df=1,vocabulary=final)
#vec = CountVectorizer(vocabulary=final)
#print(final)
#print(df.iloc[0][1])
#value = vec.fit_transform(df.iloc[2][1])
#idf=list(vectorizer.idf_)
#print(value)

#X = vectorizer.fit_transform(df.iloc[1][1])
#idf=list(vectorizer.idf_)
#print(idf)
#temp.append(idf)
templen=[]
for x in range(len(df)):
    X = vectorizer.fit_transform([df.iloc[x][1]]).toarray()
    templen.append(len((df.iloc[x][1]).split()))
    idf=list(vectorizer.idf_)
    temp.append(idf)
data=pd.DataFrame(temp)
col=np.arange(0,len(final)+2,dtype=int)
data[len(final)]=templen
data[len(final)+1]=df[0]
data.columns=col
print(data.head())
#data.to_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\10th\\smsspamcollection\\SMSSpam.csv',index=False)

