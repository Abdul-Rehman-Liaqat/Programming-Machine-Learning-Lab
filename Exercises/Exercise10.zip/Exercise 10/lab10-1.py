# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 20:15:51 2017

@author: Abdul Rehman
"""

import sklearn.svm.libsvm as svm
from sklearn.svm import SVC 
import numpy as np
from sklearn.metrics import accuracy_score as score
import pandas as pd
import time
import matplotlib.pyplot as plt

# separating target and input variables.
def sepxy(df,col):
    x=df.drop(col,axis=1)
    y=df[col]
    return x,y
'''
# normalizing the whole numerical data
def normalize(df,col):
    for x in col:
        mean=df[x].mean()
        std=df[x].std()
        df[x]=(df[x]-mean)/std
    return df
'''
def normalize(df,col):
    for x in col:
        ma=max(df[x])
        mi=min(df[x])
        df[x]=(df[x]-mi)/(ma-mi)
    return df

# Randomly shuffling the whole dataframe with respect to rows.
def shuffleit(df):
    df=df.sample(frac=1)
    return df.reset_index(drop='true')

# Separating and returning dataframe parts according to K-fold configuration.
def separate(df,k,num):
    if (k*num<=len(df) and k*2<len(df)):
        valid=df.iloc[k*(num-1):k*num]
        train=df.drop(range(k*(num-1),k*num),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    elif (k*num<=len(df) and k*2>len(df)):        
        valid=df.iloc[k*num:]
        train=df.drop(range(k*num,len(df)),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    else:
        valid=df.iloc[k*(num-1):]
        train=df.drop(range(k*(num-1),len(df)),axis=0)
        valid=valid.reset_index(drop='true')
        train=train.reset_index(drop='true')
        return train,valid
    
data=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\10th\\spambase\\spambase.data',header=None)
col=np.arange(0,58,dtype=int)
tempcol=np.arange(0,57,dtype=int)
pred=57
data.columns=col
data=shuffleit(data)
df,test=separate(data,int(0.2*len(data)),1)
print(int(0.1*len(data)))
'''
temp=[0,1,2,4,54,55,56,57]
tempnorm=[0,1,2,4,54,55,56]
#print(df.tail)
df=df[temp].iloc[0:20]
test=df[temp].iloc[-5:]
'''
df=normalize(df,tempcol)
test=normalize(test,tempcol)
#dfx,dfy=sepxy(df,pred)
testx,testy=sepxy(test,pred)
#print(dfx,dfy)
#print(testx,testy)
const=[0.001,0.01,0.1,1,10,100,1000,10000]
#const=[1,5,10]
ker=['linear','rbf','poly','sigmoid']
#ker=['linear','rbf','poly']
#ker='linear'
#clf=SVC(C=const,kernel=ker)
#clf.fit(dfx,dfy)
#prediction=clf.predict(testx)
#print(score(prediction,testy))
fold=5
err=[]
error=[]
count=0
start_time = time.time()
for a in const:
    for b in ker:
        for e in range(fold):
            ktrain,kvalid=separate(df,int(len(data)/fold),e+1)
#            print(len(ktrain),len(kvalid))
            dfx,dfy=sepxy(ktrain,pred)
            validx,validy=sepxy(kvalid,pred)
            clf=SVC(C=a,kernel=b)
#            print(count)
            clf.fit(dfx,dfy)
  #          print(time.time()-start_time)
            prediction=clf.predict(validx)
   #         print("     score is",score(prediction,validy))
            rm=score(prediction,validy)
            err.append(rm)
        print(count)
        count=count+1
        error.append((err[-1]+err[-2]+err[-3]+err[-4]+err[-5])/fold)
        
sc=np.zeros((len(const),len(ker)))
sker=np.zeros((len(ker),len(const)))

count=0
for x in range(len(const)):
    for y in range(len(ker)):
        sc[x][y]=error[count]
        if(y==0):
            sker[y][x]=error[count]
        elif(y==1):
            sker[y][x]=error[count]
        elif(y==2):
            sker[y][x]=error[count]
        elif(y==3):
            sker[y][x]=error[count]
        count=count+1

plt.figure(1)
for x in sc:
    plt.plot(range(len(x)),x*100)
plt.title('Accuracy for different C')
plt.xlabel('Type of kernel')
plt.ylabel('Accuracy percentage')
plt.xticks(range(len(ker)), ker, rotation='vertical')
plt.legend(const)
plt.show()

plt.figure(2)
for x in sker:
    plt.plot(range(len(x)),x*100)
plt.title('Accuracy for different Kernels')
plt.xlabel('Value of C')
plt.ylabel('Accuracy percentage')
plt.xticks(range(len(const)), const, rotation='vertical')
plt.legend(ker)
plt.show()




indma=np.argmax(error)
ma=max(error)
print(ma)
dfx,dfy=sepxy(df,pred)
count=0
cc=0
kk=0
for a in const:
    for b in ker:
        if(count==indma):
            cc=a
            kk=b
        count=count+1

clf=SVC(C=cc,kernel=kk)
clf.fit(dfx,dfy)
prediction=clf.predict(testx)
print("final accuracy is ",score(prediction,testy))
print("best value of C is = ",cc,"\nbest type of kernel is = :",ker)
            

'''
print(len(df))
ktrain=df.iloc[0:3000]
kvalid=df.iloc[3000:]
dfx,dfy=sepxy(ktrain,pred)
validx,validy=sepxy(kvalid,pred)
clf=SVC(C=5,kernel=ker)
print(count)    
start_time = time.time()
clf.fit(dfx,dfy)
print(time.time()-start_time)
prediction=clf.predict(validx)
print(score(prediction,validy))
'''