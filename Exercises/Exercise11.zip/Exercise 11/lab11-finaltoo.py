
import numpy as np
import pandas as pd
from random import randrange
import matplotlib.pyplot as plt
#x=np.array([[1],[3],[5],[8],[10],[12]])
import time


# separating target and input variables.
def sepxy(df,col):
    x=df.drop(col,axis=1)
    y=df[col]
    return x,y
'''
# normalizing the whole numerical data
def normalize(df,col):
    for x in col:
        mean=df[x].mean()
        std=df[x].std()
        df[x]=(df[x]-mean)/std
    return df
'''
def normalize(df,col):
    for x in col:
        ma=max(df[x])
        mi=min(df[x])
        df[x]=(df[x]-mi)/(ma-mi)
    return df

# Randomly shuffling the whole dataframe with respect to rows.
def shuffleit(df):
    df=df.sample(frac=1)
    return df.reset_index(drop='true')

    
    
    
''''    
x=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\11th\\irisData.txt')
col=['x1','x2','x3','x4','y']
tempcol=['x1','x2','x3','x4']
x.columns=col
x=x.drop('y',axis=1)
'''
x=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\11th\\newsgrouptrain.csv',header=None)
row,col=x.shape
tempcol=np.arange(0,col,dtype=int)
temcolcol=np.arange(1,(col),dtype=int)
x.columns=tempcol

'''

x=pd.read_csv('E:\\First semester\\Programming Machine Learning\\Assignments\\11th\\test.csv')
#col=['x1','x2','x3','x4','y']
tempcol=['x1','x2','x3','x4']
x.columns=tempcol
#x.columns=col

#print(len(x))
#print(x.head())
'''
x=x.drop(0,axis=1)
x=normalize(x,temcolcol)
x=shuffleit(x)

def distance(u,v):
    a=0
    a=u-v
    a=np.sqrt(sum(pow(a,2)))
#    a=(sum(pow(a,2)))
    return a

def iniEmpty(k):
    p=[]
    for a in range(k):
        p.append([])    
    return p
    
collect=[]
#itr=10
#k=4
ktemp=[20]
#ktemp=[2,4,6,8,10,12,16,20]
#ktemp=[2,3]
rr=2
checkp=0
checkdis=0
checkmiu=0
itr=5
kaddition=[]

totalmiu=[]

maincounter=0
begintime=time.time()

for k in ktemp:    
    restart=[]
    for rando in range(rr):
        
            
        miu=[]
        ra=[]
        p=iniEmpty(k)
        mi=iniEmpty(k)
        kdis=iniEmpty(k)
        ran = randrange(0,len(x))
        miu.append(x.iloc[ran])
        mindex=[ran]
        counter=0
        while (counter<k-1):
            counter=counter+1
            distan=np.zeros(len(x))
            for rowx in range(len(x)):
                a=x.iloc[rowx]
                add=0
                kdis[counter-1].append(distance(a,miu[-1]))
            for b in range(counter):
                distan=np.add(distan,kdis[b])
            ind=np.argmax(distan)
            miu.append(x.iloc[ind])
            mindex.append(ind)
            print(counter)
        
#        print('passed')
        # finding distance of each point from last centroid
        for rowx in range(len(x)):
            a=x.iloc[rowx]
            kdis[-1].append(distance(a,miu[-1]))
        totalold=0
        danger=0
#        while(danger!=-1):
        while(counter<itr):
            print(maincounter)
            maincounter=maincounter+1
            counter=counter+1
            print('entered')
#        for it in range(itr):
            p=iniEmpty(k)
            kdis=iniEmpty(k)
            pdis=iniEmpty(k)
            
            for rowx in range(len(x)):
                for b,c in zip(miu,range(k)):
                    a=x.iloc[rowx]
                    kdis[c].append(distance(a,b))
                
            a=np.arange(0,k,dtype=int)
            temp=(pd.DataFrame(kdis)).transpose()
            temp.columns=a
            
            #classifiying each point into diffferent cluster
            for rowx in range(len(x)):
                a=temp.iloc[rowx]
                ind=np.argmin(a)
                p[ind].append(x.iloc[rowx])
                pdis[ind].append(kdis[ind][rowx])
                
            #finding new centroids
            totald=0
            for a in range(k):
                temp=pd.DataFrame(p[a],columns=None)
                if(len(p[a])==0):
                    danger=-1
                    break
                else:
                    miu[a]=temp.mean(axis=0)
                totald=totald+np.mean(pdis[a])
                
            if(danger==-1):
                break
                
            if(totald==totalold):
                totalold=totald
                break
        
            totalold=totald
        totalmiu.append(miu)
#        print(begintime-time.time())
        restart.append(totald/k)
#        print(totald/k)
    collect.append(restart)
    kaddition.append(min(restart))
    plt.plot(range(rr),restart)

idhar=[]
for a in range(len(ktemp)):
    idhar.append(np.mean(collect[a]))
    
#plt.plot(tempit)
#plt.plot(kaddition)
plt.xlabel('Random Restarts')
plt.ylabel('Mean distance in in each cluster')
plt.title("Mean distance of different K's on random restarts")
plt.show

#plt.plot(collect)
#plt.show
plt.plot(ktemp,kaddition)
plt.xlabel('k')
plt.ylabel('Mean distance in in each cluster')
plt.title("Different K's vs Mean distance")
plt.show


