import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier as dtc
from sklearn.metrics import mean_squared_error as mse
import matplotlib.pyplot as plt 
from sklearn.grid_search import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cross_validation import cross_val_score
from sklearn.metrics import accuracy_score as score
from sklearn import tree

# uniques values in all non-numerical columns of data frame to find out Nan values
def colUnique(df):
    for x in df.columns:
            if df[x].dtype=='object':
                print(df[x].unique(),'\n')
                
# Converting non-numerical values to numerical values
def dummy(df):
    df=pd.get_dummies(df)
    return df               

# normalizing the whole numerical data
def normalize(df,col):
    for x in col:
        mean=df[x].mean()
        std=df[x].std()
        df[x]=(df[x]-mean)/std
    return df
    
# separating target and input variables.
def sepxy(df,col):
    x=df.drop(col,axis=1)
    y=df[col]
    return x,y

# Randomly shuffling the whole dataframe with respect to rows.
def shuffleit(df):
    return df.sample(frac=1)

# Separating and returning dataframe parts according to K-fold configuration.
def separate(df,k,num):
    if (k*num<=len(df) and k*2<len(df)):
        valid=df.iloc[k*(num-1):k*num]
        train=df.drop(range(k*(num-1),k*num),axis=0)
        return train,valid
    else:
        valid=df.iloc[k*(num-1):]
        train=df.drop(range(k*(num-1),len(df)),axis=0)
        return train,valid

def misClasRate(pre,act):
    count=0
    for x,y in zip(pre,act):
        if(x!=y):
            count=count+1
    return count/len(pre)
    
df=pd.read_csv('E:/First semester/Programming Machine Learning/Assignments/8th/irisData.txt')
df.columns=['Slength','Swidth','plength','pwidth','quality']
#df=pd.read_csv('E:/First semester/Programming Machine Learning/Assignments/8th/winequality-red.csv',sep=';')
ytopre='quality'
df.head()

df=df.dropna(axis=0)
#df=dummy(df)
df=normalize(df,df.columns[df.columns!='quality'])
df=shuffleit(df)
df=df.reset_index(drop='true')
df.head()

#df=df[['fixed acidity','volatile acidity','quality']].iloc[0:100]
#print(df.tail())

train,test=separate(df,int(0.3*len(df)),1)
xtrain,ytrain=sepxy(train,ytopre)
xtest,ytest=sepxy(test,ytopre)

#tree implementation
depth=np.arange(1,20,dtype=int)
parameters={'max_depth':depth}
dt=dtc(criterion='gini')
grid=GridSearchCV(dt,parameters,scoring='accuracy')
fitit=grid.fit(xtrain,ytrain)
pre=grid.predict(xtest)
print("\nBest accuracy score for training data = ",grid.best_score_*100,"%")
print("Best Maximum Depth    = ",grid.best_params_)
print("\n\nMis-Classification rate on test data based = ",misClasRate(pre,ytest)*100,"%")
scorelist=[]
for x in grid.grid_scores_:
    scorelist.append(x[1])
plt.scatter(depth,scorelist)
plt.xlabel('Depths')
plt.ylabel('Accuracy')
plt.title('Accuracy of prediction for different depths of data')
plt.grid()
plt.show()

#KNN classifier implementation
start=1
end=int(len(ytrain))/2
ksample=(np.arange(start,end,dtype=int))
#ksample=[1,2,3]
parameters={'n_neighbors':ksample}
grid=GridSearchCV(KNeighborsClassifier(),parameters,scoring='accuracy')
grid.fit(xtrain,ytrain)
pre=grid.predict(xtest)
print("\nBest accuracy score for training data = ",grid.best_score_*100,"%")
print("Best Maximum Depth    = ",grid.best_params_)
print("\n\nMis-Classification rate on test data based = ",misClasRate(pre,ytest)*100,"%")
#print(score(pre,ytest))
scorelist=[]
for x in grid.grid_scores_:
    scorelist.append(x[1])
plt.scatter(ksample,scorelist)
plt.xlabel('K neighbors')
plt.ylabel('Accuracy')
plt.title('Accuracy of prediction for different depths of K ')
plt.grid()
plt.show()